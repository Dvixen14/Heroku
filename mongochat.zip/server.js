const MongoClient = require("mongodb").MongoClient;
var express = require("express");
var app = express();
var http = require("http").createServer(app);
const client = require("socket.io")(3000, {
    cors: {
      origin: '*',
    }
  });
var url = "mongodb+srv://Davide:Y8jM2TdXWRs6aqZ@testcluster1.1p780.mongodb.net/mongochat";

// Connessione a MongoDB
MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    var db = db.db('mongochat');

    /*var dbo = db.db("mongochat");
    dbo.createCollection("chats", function (err, res) {
        if (err) throw err;
        console.log("Collection created!");
        db.close();
    });*/

    console.log("Connesso a MongoDB...");

    // Connessione a Socket.io
    client.on("connection", function (socket) {
        
        let chat = db.collection("chats");
        sendStatus = function (s) {
            socket.emit("status", s);
            
        };

        // Chat dalla collection su MongoDB
        chat
            .find()
            .limit(100)
            .sort({ _id: 1 })
            .toArray(function (err, res) {
                //check for errors
                if (err) {
                    throw err;
                }
                //else emit
                socket.emit("output", res);
            });

        // Gestione degli eventi input
        socket.on("input", function (data) {
            let name = data.name;
            let message = data.message;

            // Controlla nome e messaggio
            if (name == "" || message == "") {
                // Send error status
                sendStatus("Please enter a name and message");
            } else {
                // Inserimento messaggio
                chat.insert({ name: name, message: message }, function () {
                    client.emit("output", [data]);

                    // Send status object
                    sendStatus({
                        message: "Message sent",
                        clear: true,
                    });
                });
            }
        });

        // Handle clear
        socket.on("clear", function (data) {
            // Rimuove tutte la chat dalla collection
            chat.remove({}, function () {
                // Emit cleared
                socket.emit("cleared");
            });
        });
    });
});
